package org.example.biblioteca.model;

public class Biblioteca {
    private Integer id;
    private String nome;
    private String endereco;

    public Biblioteca() {}

    public Biblioteca(Integer id, String nome, String endereco) {
        this.id = id;
        this.nome = nome;
        this.endereco = endereco;
    }

    public Biblioteca(String nome, String endereco) { this(null, nome, endereco); }

    public Integer getId() { return id; }
    public void setId(Integer id) { this.id = id; }

    public String getNome() { return nome; }
    public void setNome(String nome) { this.nome = nome; }

    public String getEndereco() { return endereco; }
    public void setEndereco(String endereco) { this.endereco = endereco; }
}
